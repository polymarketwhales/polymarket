# Supported Networks and Tokens

## USDC
- BSC
- Base
- Polygon
- Arbitrum
- Optimism
- Monad
- HyperEVM

## USDC.e
- Polygon
- Abstract

## ARB
- Arbitrum

## BNB
- BSC

## BTC
- Bitcoin

## BTCB
- BSC

## BUSD
- BSC

## ETH
- Ethereum
- BSC
- Base
- Arbitrum
- Optimism
- Abstract

## TRUMP
- Solana

## SOL
- Solana

## USDT
- Ethereum
- Solana
- BSC
- Base
- Polygon
- Arbitrum
- Optimism
- HyperEVM
- Abstract
- Tron